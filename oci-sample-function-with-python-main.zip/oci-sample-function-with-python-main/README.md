# oci-sample-function-with-python
Its a sample python application to support OCI Devops with function deployment 

---------------

## Supported links 

 - [OCI Reference architecture of OCI Devops and Functions](https://docs.oracle.com/en/solutions/build-cicd-pipelines-devops-function/index.html)
 - [OCI Code base](https://github.com/oracle-quickstart/oci-arch-devops-cicd-with-functions) 



